// START original config for this file - do NOT change -> if needed for testing copy below instead
 const GAME_PLATFORM = 'web'; // web, steam, ... itch?
 const DEMO_VERSION = true; // true, false
const PUBLISHER_PLATFORM = 'web'; // wev, steam.... itch
// END original config